# Build

```
npm install
npm run-script build
```

# Use

- Turn the knob to control a MIDI parameter.
- Press and turn the knob to control a second MIDI parameter.
